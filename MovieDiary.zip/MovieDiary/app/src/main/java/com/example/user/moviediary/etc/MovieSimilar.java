package com.example.user.moviediary.etc;

public class MovieSimilar {

}
