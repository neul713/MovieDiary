package com.example.user.moviediary.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.moviediary.R;
import com.example.user.moviediary.etc.SearchResults;
import com.example.user.moviediary.util.CharacterWrapTextView;
import com.example.user.moviediary.util.GlideApp;

import java.util.ArrayList;
import java.util.List;

public class MovieSearchAdapter extends RecyclerView.Adapter<MovieSearchAdapter.SearchViewHolder> implements Filterable {

    private List<SearchResults.ResultsBean> list;
    private List<SearchResults.ResultsBean> listFull;
    private int layout;
    private View view;
    private Context context;

    private OnItemSelectedInterface mListener;

    public MovieSearchAdapter(int layout, List<SearchResults.ResultsBean> list, OnItemSelectedInterface mListener) {
        this.list = list;
        this.layout = layout;
        this.mListener = mListener;
        this.listFull = new ArrayList<>(list);
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        view = LayoutInflater.from(viewGroup.getContext()).inflate(layout, viewGroup, false);
        SearchViewHolder searchViewHolder = new SearchViewHolder(view);
        context = viewGroup.getContext();
        return searchViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder searchViewHolder, int i) {

        final SearchResults.ResultsBean searchResultBean = list.get(i);

        searchViewHolder.title.setText(searchResultBean.getTitle());
        searchViewHolder.overview.setText(searchResultBean.getOverview());

        if (searchResultBean.getPoster_path()!=null) {
            String url = "https://image.tmdb.org/t/p/w92" + searchResultBean.getPoster_path();

            GlideApp.with(searchViewHolder.itemView).load(url)
                    .centerCrop()
                    .into(searchViewHolder.poster);
        }

        //클릭이벤트
        searchViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int movieID = searchResultBean.getId();
                mListener.onItemSelected(v, movieID);

            }
        });

        searchViewHolder.overview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int movieID = searchResultBean.getId();
                mListener.onItemSelected(v, movieID);

            }
        });
    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    public class SearchViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        CharacterWrapTextView overview;
        ImageView poster;

        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            this.title = itemView.findViewById(R.id.title);
            this.overview = itemView.findViewById(R.id.overview);
            this.poster = itemView.findViewById(R.id.poster);
        }
    }

    @Override
    public Filter getFilter() {
        return searchFilter;
    }

    private Filter searchFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<SearchResults.ResultsBean> filteredList = new ArrayList<>();
            //검색어의 변화가 없을때 : listFull이 모든항목을 그대로 다 받아서 유지
            if(constraint ==null || constraint.length() ==0) {
                filteredList.addAll(listFull);
            }else{
                //검색어의 변화가 있을때 : 영어일수도 있으므로 비교를위해 소문자로 검색어를 모두 치환
                String filterPattern = constraint.toString().toLowerCase().trim();

                for(SearchResults.ResultsBean item : listFull){
                    //해당 변경된 검색어가 들어있는 item은 남겨두기
                    if(item.getTitle().toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            //기존리스트를 지우고 필터링된 리스트로 채우기
            list.clear();
            list.addAll((List)results.values);
            notifyDataSetChanged();
        }
    };

    public interface OnItemSelectedInterface {
        void onItemSelected(View v, int movieID);
    }

}
