package com.example.user.moviediary.util;

public class DeveloperKey {
    public static final String YOUTUBE = "AIzaSyD9QUhq0S_bF1GUu1x8jQrrqwGA0U_tILY";
    public static final String TMDB = "38bc08964511ed116095cae682ec9c13";

}
